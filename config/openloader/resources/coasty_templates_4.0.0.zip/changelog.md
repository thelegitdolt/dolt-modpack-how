# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [4.0.0] 2025-07-16

### Added
- Supporting 6 template models from the following mods:
  - **Galosphere:** Preserved Upgrade, Silver Upgrade
  - **Musket Mod:** Musket Upgrade
  - **Wan's Ancient Beasts:** Ancient Upgrade, Sniff, Spike
  - Total template model count: 41

## [3.0.0] - 2025-05-06

### Added
- Supporting 3 template models from the following mods:
  - **NewWorld:** Mattock Crafting
  - **Wetland Whimsy:** Dots
  - **Wilderness:** Roots

### Changed:
- **JNE** Valor trim's glow is now on the bottom of the model, rather than on the rim.

## [2.0.0] - 2025-04-19

### Added
- Mod Batch 1: Supporting 13 template models from the following mods:
  - **Atmospheric:** Apostle, Druid, Petrified
  - **Caverns and Chasms:** Exile
  - **Hominid:** Remains
  - **Jaden's Nether Expansion:** Pump-Charge Upgrade, Rift, Spirit, Valor
  - **Neapolitan:** Primal
  - **Quark:** Runic Etching
  - **Sully's Mod:** Jade Upgrade

## [1.0.0] - 2025-04-15

- Initial releasse.
